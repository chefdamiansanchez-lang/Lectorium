package com.lectorvoz.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.isSystemInDarkTheme

private val AzulPrincipal = Color(0xFF2F5D8C)
private val AzulOscuro = Color(0xFF16324F)
private val Acento = Color(0xFFE8A33D)

private val EsquemaClaro = lightColorScheme(
    primary = AzulPrincipal,
    secondary = Acento,
    background = Color(0xFFF7F7F7),
    surface = Color.White
)

private val EsquemaOscuro = darkColorScheme(
    primary = AzulPrincipal,
    secondary = Acento,
    background = AzulOscuro,
    surface = Color(0xFF1E1E1E)
)

@Composable
fun LectorVozTheme(content: @Composable () -> Unit) {
    val esquema = if (isSystemInDarkTheme()) EsquemaOscuro else EsquemaClaro
    MaterialTheme(colorScheme = esquema, content = content)
}
