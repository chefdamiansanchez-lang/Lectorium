package com.lectorvoz.app.data

import android.content.Context
import android.net.Uri
import com.lectorvoz.app.parser.EpubParser
import com.lectorvoz.app.parser.PdfParser
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Se encarga de:
 * 1) Copiar el archivo que el usuario eligió (desde el selector del sistema) a la
 *    carpeta privada de la app, para tener acceso estable a él.
 * 2) Parsear su contenido (EPUB o PDF) en capítulos de texto.
 * 3) Guardar/leer la lista de libros y el progreso de lectura en un JSON local.
 */
class LibraryRepository(private val context: Context) {

    private val carpetaLibros: File
        get() = File(context.filesDir, "libros").apply { mkdirs() }

    fun importarArchivo(uri: Uri, nombreOriginal: String): Libro {
        val esEpub = nombreOriginal.endsWith(".epub", ignoreCase = true)
        val formato = if (esEpub) FormatoLibro.EPUB else FormatoLibro.PDF
        val id = UUID.randomUUID().toString()
        val extension = if (esEpub) "epub" else "pdf"
        val destino = File(carpetaLibros, "$id.$extension")

        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir el archivo seleccionado" }
            destino.outputStream().use { output -> input.copyTo(output) }
        }

        val libro = if (esEpub) {
            val resultado = EpubParser.parsear(destino)
            Libro(
                id = id,
                titulo = resultado.titulo,
                autor = resultado.autor,
                formato = FormatoLibro.EPUB,
                rutaArchivo = destino.absolutePath,
                capitulos = resultado.capitulos
            )
        } else {
            val resultado = PdfParser.parsear(destino)
            Libro(
                id = id,
                titulo = resultado.titulo,
                autor = null,
                formato = FormatoLibro.PDF,
                rutaArchivo = destino.absolutePath,
                capitulos = resultado.capitulos
            )
        }

        val actuales = obtenerBiblioteca().toMutableList()
        actuales.add(libro)
        guardarBiblioteca(actuales)
        return libro
    }

    fun obtenerBiblioteca(): List<Libro> {
        val archivoIndice = File(context.filesDir, INDICE)
        if (!archivoIndice.exists()) return emptyList()
        return try {
            deserializar(archivoIndice.readText())
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun actualizarProgreso(libroId: String, capitulo: Int, posicion: Int) {
        val lista = obtenerBiblioteca().map {
            if (it.id == libroId) it.copy(capituloActual = capitulo, posicionCaracter = posicion) else it
        }
        guardarBiblioteca(lista)
    }

    fun eliminarLibro(libroId: String) {
        val libro = obtenerBiblioteca().find { it.id == libroId }
        libro?.let { File(it.rutaArchivo).delete() }
        guardarBiblioteca(obtenerBiblioteca().filterNot { it.id == libroId })
    }

    private fun guardarBiblioteca(libros: List<Libro>) {
        val arreglo = JSONArray()
        libros.forEach { libro ->
            val obj = JSONObject()
            obj.put("id", libro.id)
            obj.put("titulo", libro.titulo)
            obj.put("autor", libro.autor)
            obj.put("formato", libro.formato.name)
            obj.put("rutaArchivo", libro.rutaArchivo)
            obj.put("capituloActual", libro.capituloActual)
            obj.put("posicionCaracter", libro.posicionCaracter)
            val capitulosArr = JSONArray()
            libro.capitulos.forEach { cap ->
                val capObj = JSONObject()
                capObj.put("titulo", cap.titulo)
                capObj.put("texto", cap.texto)
                capitulosArr.put(capObj)
            }
            obj.put("capitulos", capitulosArr)
            arreglo.put(obj)
        }
        File(context.filesDir, INDICE).writeText(arreglo.toString())
    }

    private fun deserializar(contenido: String): List<Libro> {
        if (contenido.isBlank()) return emptyList()
        val arreglo = JSONArray(contenido)
        return (0 until arreglo.length()).map { i ->
            val obj = arreglo.getJSONObject(i)
            val capitulosArr = obj.optJSONArray("capitulos") ?: JSONArray()
            val capitulos = (0 until capitulosArr.length()).map { j ->
                val capObj = capitulosArr.getJSONObject(j)
                Capitulo(titulo = capObj.getString("titulo"), texto = capObj.getString("texto"))
            }
            Libro(
                id = obj.getString("id"),
                titulo = obj.getString("titulo"),
                autor = obj.optString("autor", null).takeIf { !obj.isNull("autor") },
                formato = FormatoLibro.valueOf(obj.getString("formato")),
                rutaArchivo = obj.getString("rutaArchivo"),
                capituloActual = obj.optInt("capituloActual", 0),
                posicionCaracter = obj.optInt("posicionCaracter", 0),
                capitulos = capitulos
            )
        }
    }

    companion object {
        private const val INDICE = "biblioteca.json"
    }
}
