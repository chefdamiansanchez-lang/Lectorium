package com.lectorvoz.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class LectorVozApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CANAL_LECTURA,
                "Lectura en voz alta",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controles de reproducción mientras se lee un libro"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(canal)
        }
    }

    companion object {
        const val CANAL_LECTURA = "canal_lectura_voz"
    }
}
