package com.lectorvoz.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.lectorvoz.app.parser.PdfParser
import com.lectorvoz.app.ui.LibraryScreen
import com.lectorvoz.app.ui.LibraryViewModel
import com.lectorvoz.app.ui.ReaderScreen
import com.lectorvoz.app.ui.theme.LectorVozTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LibraryViewModel by viewModels()

    private val pedirNotificaciones = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* si la deniega, la app sigue funcionando pero sin notificación visible */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        PdfParser.inicializar(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pedirNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            LectorVozTheme {
                val libroAbierto by viewModel.libroAbierto.collectAsState()
                val libro = libroAbierto
                if (libro == null) {
                    LibraryScreen(
                        viewModel = viewModel,
                        onAbrirLibro = { viewModel.abrirLibro(it) }
                    )
                } else {
                    ReaderScreen(
                        libro = libro,
                        viewModel = viewModel,
                        onVolver = { viewModel.actualizarBiblioteca() }
                    )
                }
            }
        }
    }
}
