package com.lectorvoz.app.tts

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.lectorvoz.app.LectorVozApp
import com.lectorvoz.app.MainActivity
import java.util.Locale
import java.util.UUID

/**
 * Servicio en primer plano: mantiene el TextToSpeech vivo aunque el usuario
 * salga de la app o apague la pantalla.
 */
class TtsReaderService : Service(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val binder = TtsBinder()

    // Estado expuesto a la UI
    var estado = EstadoLectura.DETENIDO
        private set
    var alTerminarFrase: ((Int) -> Unit)? = null // devuelve el índice de frase leída
    var alCambiarEstado: ((EstadoLectura) -> Unit)? = null

    private var frases: List<String> = emptyList()
    private var indiceActual = 0

    inner class TtsBinder : Binder() {
        fun obtenerServicio(): TtsReaderService = this@TtsReaderService
    }

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("es", "ES")
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    indiceActual++
                    alTerminarFrase?.invoke(indiceActual)
                    if (indiceActual < frases.size && estado == EstadoLectura.REPRODUCIENDO) {
                        hablarFrase(indiceActual)
                    } else if (indiceActual >= frases.size) {
                        cambiarEstado(EstadoLectura.DETENIDO)
                    }
                }
                override fun onError(utteranceId: String?) {}
            })
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        iniciarPrimerPlano()
        return START_NOT_STICKY
    }

    /** Divide el texto en frases y empieza (o continúa) a leer desde [posicionCaracter]. */
    fun leerTexto(texto: String, posicionInicial: Int = 0) {
        frases = dividirEnFrases(texto)
        indiceActual = calcularIndiceDesdeCaracter(posicionInicial)
        cambiarEstado(EstadoLectura.REPRODUCIENDO)
        iniciarPrimerPlano()
        hablarFrase(indiceActual)
    }

    fun pausar() {
        tts?.stop()
        cambiarEstado(EstadoLectura.PAUSADO)
    }

    fun reanudar() {
        if (indiceActual < frases.size) {
            cambiarEstado(EstadoLectura.REPRODUCIENDO)
            hablarFrase(indiceActual)
        }
    }

    fun detener() {
        tts?.stop()
        cambiarEstado(EstadoLectura.DETENIDO)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun cambiarVelocidad(velocidad: Float) {
        tts?.setSpeechRate(velocidad)
    }

    private fun hablarFrase(indice: Int) {
        val frase = frases.getOrNull(indice) ?: return
        val idUtterance = UUID.randomUUID().toString()
        tts?.speak(frase, TextToSpeech.QUEUE_FLUSH, null, idUtterance)
    }

    private fun cambiarEstado(nuevo: EstadoLectura) {
        estado = nuevo
        alCambiarEstado?.invoke(nuevo)
    }

    private fun dividirEnFrases(texto: String): List<String> {
        return texto.split(Regex("(?<=[.!?…])\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }

    private fun calcularIndiceDesdeCaracter(posicionCaracter: Int): Int {
        var acumulado = 0
        frases.forEachIndexed { index, frase ->
            acumulado += frase.length + 1
            if (acumulado >= posicionCaracter) return index
        }
        return 0
    }

    private fun iniciarPrimerPlano() {
        val intentAbrirApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notificacion: Notification = NotificationCompat.Builder(this, LectorVozApp.CANAL_LECTURA)
            .setContentTitle("Leyendo en voz alta")
            .setContentText("Toca para volver a la app")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(intentAbrirApp)
            .setOngoing(true)
            .build()
        startForeground(1, notificacion)
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

enum class EstadoLectura { REPRODUCIENDO, PAUSADO, DETENIDO }
