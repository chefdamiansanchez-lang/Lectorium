package com.lectorvoz.app.parser

import android.content.Context
import com.lectorvoz.app.data.Capitulo
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

object PdfParser {

    data class ResultadoPdf(
        val titulo: String,
        val capitulos: List<Capitulo>
    )

    private const val PAGINAS_POR_CAPITULO = 5

    fun inicializar(context: Context) {
        // PdfBox-Android necesita cargar sus recursos una vez, al arrancar la app
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    fun parsear(archivo: File): ResultadoPdf {
        PDDocument.load(archivo).use { documento ->
            val extractor = PDFTextStripper()
            val totalPaginas = documento.numberOfPages
            val capitulos = mutableListOf<Capitulo>()

            var pagina = 1
            var numeroCapitulo = 1
            while (pagina <= totalPaginas) {
                val paginaFin = minOf(pagina + PAGINAS_POR_CAPITULO - 1, totalPaginas)
                extractor.startPage = pagina
                extractor.endPage = paginaFin
                val texto = extractor.getText(documento).trim()
                if (texto.isNotBlank()) {
                    capitulos.add(
                        Capitulo(
                            titulo = "Páginas $pagina–$paginaFin",
                            texto = texto
                        )
                    )
                }
                numeroCapitulo++
                pagina = paginaFin + 1
            }

            val titulo = documento.documentInformation?.title?.takeIf { it.isNotBlank() }
                ?: archivo.nameWithoutExtension

            return ResultadoPdf(titulo = titulo, capitulos = capitulos)
        }
    }
}
