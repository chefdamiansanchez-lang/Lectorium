package com.lectorvoz.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lectorvoz.app.data.Libro
import com.lectorvoz.app.tts.EstadoLectura

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    libro: Libro,
    viewModel: LibraryViewModel,
    onVolver: () -> Unit
) {
    val estado by viewModel.estadoLectura.collectAsState()
    var velocidad by remember { mutableFloatStateOf(1.0f) }
    val capitulo = libro.capitulos.getOrNull(libro.capituloActual)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(libro.titulo, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.cerrarLibro()
                        onVolver()
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        },
        bottomBar = {
            Column(Modifier.padding(16.dp)) {
                Text("Velocidad: ${"%.1f".format(velocidad)}x")
                Slider(
                    value = velocidad,
                    onValueChange = {
                        velocidad = it
                        viewModel.cambiarVelocidad(it)
                    },
                    valueRange = 0.5f..2.0f
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        viewModel.irACapitulo(libro.capituloActual - 1)
                    }) {
                        Icon(Icons.Default.SkipPrevious, contentDescription = "Capítulo anterior")
                    }

                    FilledIconButton(
                        modifier = Modifier.size(64.dp),
                        onClick = {
                            when (estado) {
                                EstadoLectura.REPRODUCIENDO -> viewModel.pausar()
                                EstadoLectura.PAUSADO -> viewModel.reanudar()
                                EstadoLectura.DETENIDO -> viewModel.reproducir()
                            }
                        }
                    ) {
                        Icon(
                            if (estado == EstadoLectura.REPRODUCIENDO) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Reproducir/Pausar",
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    IconButton(onClick = {
                        viewModel.irACapitulo(libro.capituloActual + 1)
                    }) {
                        Icon(Icons.Default.SkipNext, contentDescription = "Capítulo siguiente")
                    }
                }
                Text(
                    "Capítulo ${libro.capituloActual + 1} de ${libro.capitulos.size}",
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(capitulo?.titulo ?: "", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            Text(capitulo?.texto ?: "Este libro no tiene texto para leer.")
        }
    }
}
