package com.lectorvoz.app.ui

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lectorvoz.app.data.Libro
import com.lectorvoz.app.data.LibraryRepository
import com.lectorvoz.app.tts.EstadoLectura
import com.lectorvoz.app.tts.TtsReaderService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class LibraryViewModel(application: Application) : AndroidViewModel(application) {

    private val repositorio = LibraryRepository(application)

    private val _biblioteca = MutableStateFlow<List<Libro>>(emptyList())
    val biblioteca: StateFlow<List<Libro>> = _biblioteca

    private val _libroAbierto = MutableStateFlow<Libro?>(null)
    val libroAbierto: StateFlow<Libro?> = _libroAbierto

    private val _estadoLectura = MutableStateFlow(EstadoLectura.DETENIDO)
    val estadoLectura: StateFlow<EstadoLectura> = _estadoLectura

    private val _cargando = MutableStateFlow(false)
    val cargando: StateFlow<Boolean> = _cargando

    private var servicioTts: TtsReaderService? = null
    private val conexion = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            servicioTts = (binder as TtsReaderService.TtsBinder).obtenerServicio()
            servicioTts?.alCambiarEstado = { _estadoLectura.value = it }
            servicioTts?.alTerminarFrase = { indiceFrase ->
                libroAbierto.value?.let { repositorio.actualizarProgreso(it.id, it.capituloActual, indiceFrase) }
            }
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            servicioTts = null
        }
    }

    init {
        actualizarBiblioteca()
        val contexto = getApplication<Application>()
        contexto.bindService(
            Intent(contexto, TtsReaderService::class.java),
            conexion,
            Context.BIND_AUTO_CREATE
        )
    }

    fun actualizarBiblioteca() {
        _biblioteca.value = repositorio.obtenerBiblioteca()
    }

    fun importarArchivo(uri: Uri, nombreOriginal: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _cargando.value = true
            try {
                repositorio.importarArchivo(uri, nombreOriginal)
                actualizarBiblioteca()
            } finally {
                _cargando.value = false
            }
        }
    }

    fun eliminarLibro(libroId: String) {
        repositorio.eliminarLibro(libroId)
        actualizarBiblioteca()
    }

    fun abrirLibro(libro: Libro) {
        _libroAbierto.value = libro
    }

    fun cerrarLibro() {
        servicioTts?.detener()
        _libroAbierto.value = null
    }

    fun reproducir() {
        val libro = _libroAbierto.value ?: return
        val capitulo = libro.capitulos.getOrNull(libro.capituloActual) ?: return
        val contexto = getApplication<Application>()
        contexto.startForegroundService(Intent(contexto, TtsReaderService::class.java))
        servicioTts?.leerTexto(capitulo.texto, libro.posicionCaracter)
    }

    fun pausar() = servicioTts?.pausar()
    fun reanudar() = servicioTts?.reanudar()

    fun irACapitulo(indice: Int) {
        val libro = _libroAbierto.value ?: return
        if (indice !in libro.capitulos.indices) return
        _libroAbierto.value = libro.copy(capituloActual = indice, posicionCaracter = 0)
        repositorio.actualizarProgreso(libro.id, indice, 0)
        reproducir()
    }

    fun cambiarVelocidad(velocidad: Float) = servicioTts?.cambiarVelocidad(velocidad)

    override fun onCleared() {
        getApplication<Application>().unbindService(conexion)
        super.onCleared()
    }
}
