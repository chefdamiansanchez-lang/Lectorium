package com.lectorvoz.app.data

enum class FormatoLibro { EPUB, PDF }

data class Capitulo(
    val titulo: String,
    val texto: String
)

data class Libro(
    val id: String,
    val titulo: String,
    val autor: String?,
    val formato: FormatoLibro,
    val rutaArchivo: String, // ruta en el almacenamiento interno de la app
    val capitulos: List<Capitulo> = emptyList(),
    // progreso de lectura
    val capituloActual: Int = 0,
    val posicionCaracter: Int = 0
)
