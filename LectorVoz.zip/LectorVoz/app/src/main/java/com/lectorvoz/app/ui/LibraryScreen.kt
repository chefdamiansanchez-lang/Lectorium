package com.lectorvoz.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lectorvoz.app.data.FormatoLibro
import com.lectorvoz.app.data.Libro

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    onAbrirLibro: (Libro) -> Unit
) {
    val biblioteca by viewModel.biblioteca.collectAsState()
    val cargando by viewModel.cargando.collectAsState()
    val contexto = LocalContext.current

    val selectorArchivos = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val nombre = obtenerNombreArchivo(contexto, uri)
            viewModel.importarArchivo(uri, nombre)
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Mi biblioteca") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                selectorArchivos.launch(arrayOf("application/epub+zip", "application/pdf"))
            }) {
                Icon(Icons.Default.Add, contentDescription = "Agregar libro")
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (biblioteca.isEmpty() && !cargando) {
                Column(
                    Modifier.align(Alignment.Center).padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.MenuBook,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("Todavía no agregaste ningún libro")
                    Spacer(Modifier.height(4.dp))
                    Text("Tocá el botón + para elegir un EPUB o PDF de tu celular")
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(biblioteca, key = { it.id }) { libro ->
                        ItemLibro(
                            libro = libro,
                            onClick = { onAbrirLibro(libro) },
                            onEliminar = { viewModel.eliminarLibro(libro.id) }
                        )
                    }
                }
            }

            if (cargando) {
                Box(
                    Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(8.dp))
                        Text("Importando y procesando el libro…")
                    }
                }
            }
        }
    }
}

@Composable
private fun ItemLibro(libro: Libro, onClick: () -> Unit, onEliminar: () -> Unit) {
    ListItem(
        headlineContent = { Text(libro.titulo) },
        supportingContent = {
            val autor = libro.autor?.let { "$it · " } ?: ""
            Text("$autor${if (libro.formato == FormatoLibro.EPUB) "EPUB" else "PDF"} · ${libro.capitulos.size} capítulos")
        },
        leadingContent = { Icon(Icons.Default.MenuBook, contentDescription = null) },
        trailingContent = {
            IconButton(onClick = onEliminar) {
                Icon(Icons.Default.Delete, contentDescription = "Eliminar")
            }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
    HorizontalDivider()
}

private fun obtenerNombreArchivo(contexto: android.content.Context, uri: android.net.Uri): String {
    var nombre = "libro"
    contexto.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val indice = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (indice >= 0 && cursor.moveToFirst()) {
            nombre = cursor.getString(indice)
        }
    }
    return nombre
}
