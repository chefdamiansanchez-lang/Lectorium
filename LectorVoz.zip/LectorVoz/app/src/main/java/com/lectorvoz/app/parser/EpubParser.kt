package com.lectorvoz.app.parser

import com.lectorvoz.app.data.Capitulo
import nl.siegmann.epublib.epub.EpubReader
import org.jsoup.Jsoup
import java.io.File
import java.io.FileInputStream

object EpubParser {

    data class ResultadoEpub(
        val titulo: String,
        val autor: String?,
        val capitulos: List<Capitulo>
    )

    fun parsear(archivo: File): ResultadoEpub {
        FileInputStream(archivo).use { input ->
            val libro = EpubReader().readEpub(input)
            val titulo = libro.title ?: archivo.nameWithoutExtension
            val autor = libro.metadata?.authors?.firstOrNull()?.let {
                "${it.firstname} ${it.lastname}".trim()
            }

            val capitulos = libro.contents.mapIndexedNotNull { index, resource ->
                val html = String(resource.data, Charsets.UTF_8)
                val textoPlano = Jsoup.parse(html).text().trim()
                if (textoPlano.isBlank()) {
                    null
                } else {
                    val tituloCapitulo = Jsoup.parse(html)
                        .select("h1, h2, h3")
                        .firstOrNull()?.text()
                        ?: "Capítulo ${index + 1}"
                    Capitulo(titulo = tituloCapitulo, texto = textoPlano)
                }
            }

            return ResultadoEpub(titulo = titulo, autor = autor, capitulos = capitulos)
        }
    }
}
