# Lector de Voz 📖🔊

App Android para leer libros **EPUB** y **PDF** en voz alta, con acceso a los archivos del celular.

## Cómo abrirla

1. Descomprimí el .zip.
2. Abrí la carpeta `LectorVoz` con **Android Studio** (Hedgehog o más nuevo).
3. Dejá que sincronice Gradle (va a descargar las dependencias la primera vez, necesita internet).
4. Conectá tu celular o usá un emulador y tocá **Run**.

## Qué hace ya

- Botón "+" para elegir un archivo **.epub** o **.pdf** desde cualquier carpeta del celular (Descargas, Drive, etc.) usando el selector nativo de Android.
- Copia el archivo a la carpeta privada de la app y lo divide en capítulos:
  - **EPUB**: usa los capítulos reales del libro.
  - **PDF**: agrupa el texto cada 5 páginas (no todos los PDF tienen texto seleccionable — los escaneados como imagen no se pueden leer así).
- Pantalla de lectura con **Play/Pausa**, capítulo anterior/siguiente y control de **velocidad de voz**.
- La lectura en voz alta sigue sonando si salís de la app o apagás la pantalla (corre en un servicio en primer plano, con una notificación).
- Guarda el progreso (capítulo y frase) para retomar donde quedaste.

## Ideas para seguir mejorando

- Resaltar en pantalla la frase que se está leyendo en ese momento.
- Elegir entre distintas voces/idiomas instalados en el celular.
- Soporte para PDF escaneados (OCR) — hoy solo lee el texto que el PDF ya trae.
- Marcadores y notas.
- Publicar el proyecto en GitHub, como hicimos con las otras apps.

Contame si querés que sigamos por alguna de estas, o si algo no compila y lo revisamos.
